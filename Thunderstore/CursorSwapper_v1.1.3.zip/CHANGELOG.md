| `Version`   | `Update Notes`                                                                                          |
|-------------|---------------------------------------------------------------------------------------------------------|
| 1.1.3       | - Courtesy update for Valheim 0.217.22, nothing changed except a version bump.                          |
| 1.1.1/1.1.2 | - Remove ServerSync, not sure why I had it here. It's not needed, and would cause issues for Crossplay. |
| 1.1.0       | - No longer require reboot to apply changes to the cursor.                                              |
| 1.0.0       | - Initial Release                                                                                       |